function tcpSuite() {
	this.xmlHttp = null;
	this.obtainHttpRequestObject = obtainHttpRequestObject;
	this.obtainHttpRequestObject();
}

var suite = new tcpSuite();

function obtainHttpRequestObject() {
	if (this.xmlHttp != null) {
		alert("xmlHttp is not null...");
		return this.xmlHttp;
	}

	try	{
		// Firefox, Opera 8.0+, Safari
		this.xmlHttp=new XMLHttpRequest();
	} catch (e) {
		// Internet Explorer
		try {
			this.xmlHttp=new ActiveXObject("Msxml2.XMLHTTP");
		} catch (e) {
			try {
				this.xmlHttp=new ActiveXObject("Microsoft.XMLHTTP");
			}
			catch (e) {
				alert("Your browser does not support AJAX!");
				return false;
			}
		}
	}
}

function myalert() {
	alert("Hello, World!");
}